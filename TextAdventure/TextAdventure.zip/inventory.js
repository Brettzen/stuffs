var bokken;
var getBokken;
var pin;
var getPin;

bokken = {
	"use": "What do you want to use the <span class='items'>bokken</span> on?",
	"attack": 7,
	"description": "Your most treasured possession. This was left on your bed by a mysterious old man over a year ago. You haven't let it out of your sight since."
}

pin = {
	"use": "What do you want to use the <span class='items'>pin</span> on?",
	"description": "It's a small, metal pin. It's a lot sturdier than it looks."
}