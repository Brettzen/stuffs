var hero;

hero = {
	"Level": 2,
	"HP": 10,
	"STR": 2,
	"DEF": 2,
	"SPD": 7
};