var hero;

hero = {
	name: userName,
	level: 2,
	hp: 10,
	str: 2,
	def: 2,
	spd: 7
};

gugliemumu = {

	name: "Sister Gugliemumu",
	level: 5,
	hp: 50,
	str: 5,
	def: 5,
	spd: 5
}